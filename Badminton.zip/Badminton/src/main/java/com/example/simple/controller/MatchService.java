package com.example.simple.controller;
import java.time.Duration;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
//import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlProcessor.MatchStatus;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.simple.model.Matchstatus;
import com.example.simple.model.Matchdetails;
import com.example.simple.model.Player_details;
import com.example.simple.repository.Mathchdetailsrepo;
import com.example.simple.repository.Player_details_repo;

//import ch.qos.logback.core.util.Duration;

@RestController
public class MatchService {
	@Autowired
	Mathchdetailsrepo matchrepo;
	@Autowired
	Player_details_repo playerrepo;
	@PostMapping("/insert/match")
	public ResponseEntity<?> createdata(@RequestBody Matchdetails match){
		match.setMatch_status(Matchstatus.STARTED);
		
			if(matchrepo.findByCourtNoAndMatchstatus(match.getCourtNo(),match.getMatch_status()).isEmpty()) {
			Matchdetails _match=matchrepo.save(new Matchdetails(match.getCourtNo(),match.getMatch_status(),
					find(match.getPlayer_1_phone_no()),find(match.getPlayer_2_phone_no()),match.getStart_date_time(),
					match.getEnd_date_time(),match.getLoser_phone_no(),match.getAmount()));
			return new ResponseEntity<>("Match Started", HttpStatus.CREATED);
			}
			else {
				System.out.println("Match Running");
			return new ResponseEntity<>("some one blocked or player not found", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	public String find(String player_1_phone_no) {
		
		Player_details p= playerrepo.findById(player_1_phone_no).orElse(null);
		return p.getPhonenumber();
	}
	@PutMapping("/update/match")
	public ResponseEntity<Matchdetails> updatedata(@RequestBody Matchdetails match){
		try {
			Matchdetails match1=matchrepo.findById(match.getId()).orElse(null);
			match1.setEnd_date_time(match.getEnd_date_time());
			
			match1.setLoser_phone_no(match.getLoser_phone_no());
			match1.setMatch_status(Matchstatus.ENDED);
			match1.setAmount(duration(match1.getStart_date_time(),match.getEnd_date_time()));
		
			Matchdetails _match=matchrepo.save(match1);
			
			
			Player_details id=playerrepo.findById(match.getLoser_phone_no()).orElseThrow();
			double d=duration(match1.getStart_date_time(),match.getEnd_date_time());
			id.setAccount_balance(d);
			playerrepo.save(new Player_details(id.getPhonenumber(),id.getName(),id.getAccount_balance()));
			
			
			return new ResponseEntity<>(_match,HttpStatus.CREATED);
		}catch(Exception e) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	private double duration(LocalDateTime start_date_time, LocalDateTime end_date_time) {
		// TODO Auto-generated method stub
		double d=Duration.between(start_date_time,end_date_time).toMinutes();
		return d*2;
	}
	@GetMapping("/print/match")
	public List<Matchdetails> findAll(){
		return matchrepo.findAll();
	}
	
	@GetMapping("/print/match/range")
	public List<Matchdetails> getmatchdetailswithinrange(@RequestBody Matchdetails match){
		
		return matchrepo.findByStartdatetimeBetween(match.getStart_date_time(),match.getEnd_date_time());
	}
	
	@GetMapping("/print/match/range/phonenumber")
	public Set<Matchdetails> getmatchdetailswithinrange1(@RequestBody Matchdetails match){
		Set<Matchdetails>player=new HashSet<>();
		List<Matchdetails>player1= matchrepo.findByPlayer1phonenoAndStartdatetimeBetween(match.getPlayer_1_phone_no(),match.getStart_date_time(),match.getEnd_date_time());
		List<Matchdetails>player2=matchrepo.findByPlayer2phonenoAndStartdatetimeBetween(match.getPlayer_2_phone_no(),match.getStart_date_time(),match.getEnd_date_time());
		player.addAll(player1);
		player.addAll(player2);
		return player;
	}
	

}
