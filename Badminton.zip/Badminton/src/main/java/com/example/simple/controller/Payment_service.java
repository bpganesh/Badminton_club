package com.example.simple.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.simple.model.Payment_details;
import com.example.simple.model.Player_details;
import com.example.simple.repository.Payment_details_repo;
import com.example.simple.repository.Player_details_repo;

@RestController
public class Payment_service {
	@Autowired
	Payment_details_repo paymentrepo;
	@Autowired
	Player_details_repo playerrepo;
	@PostMapping("/insert/payment")
	public ResponseEntity<?> createpayment(@RequestBody Payment_details payment){
		try {
			Payment_details _payment=paymentrepo.save(new Payment_details(find(payment.getPlayer_phone_number()),
					payment.getDate_of_payment(),payment.getAmount_paid()));
			
			Player_details id=playerrepo.findById(payment.getPlayer_phone_number()).orElse(null);
			id.setAccount_balance(id.getAccount_balance()-payment.getAmount_paid());
			
			playerrepo.save(new Player_details(id.getPhonenumber(),id.getName(),id.getAccount_balance()));
			
			
			return new ResponseEntity<>("Transaction Successfully ", HttpStatus.CREATED);
		}catch(Exception e) {
			return new ResponseEntity<>( "Player not found", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	private String find(String player_phone_number) {
		// TODO Auto-generated method stub
		Player_details p=playerrepo.findById(player_phone_number).orElse(null);
		return p.getPhonenumber();
	}
	@GetMapping("/print/payment")
	public List<Payment_details> findall(){
		return paymentrepo.findAll();
	}
	@GetMapping("/print/payment/{phonenumber}")
	public Payment_details findbyPhonenumber(@PathVariable("phonenumber") String phone) {
		return paymentrepo.findById(phone).orElse(null);
		
	}

}
