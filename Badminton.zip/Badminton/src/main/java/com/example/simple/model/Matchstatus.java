package com.example.simple.model;

public enum Matchstatus{
STARTED,ENDED
}
